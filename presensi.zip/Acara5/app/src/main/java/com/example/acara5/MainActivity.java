package com.example.acara5;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;


import com.example.acara5.databinding.ActivityMainBinding;

import java.util.Date;

public class MainActivity extends AppCompatActivity {
    private ActivityMainBinding binding;

    private final String[] kehadiran = {
            "Hadir Tepat Waktu",
            "Sakit",
            "Terlambat",
            "Izin"
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(LayoutInflater.from(this));

        setContentView(binding.getRoot());

        ArrayAdapter<String> adapterKehadiran =
                new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, kehadiran);
        adapterKehadiran.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.kehadiran.setAdapter(adapterKehadiran);


        binding.datePicker.init(
                binding.datePicker.getYear(),
                binding.datePicker.getMonth(),
                binding.datePicker.getDayOfMonth(),
                new DatePicker.OnDateChangedListener() {
                    @Override
                    public void onDateChanged(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        String selectedDate = dayOfMonth + "/" + (monthOfYear) + "/" + year;
                        Toast.makeText(MainActivity.this, selectedDate, Toast.LENGTH_LONG).show();
                    }
                }
        );
        binding.timePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                String selectedTime = String.format("%02d:%02d", hourOfDay, minute);
                Toast.makeText(MainActivity.this, selectedTime, Toast.LENGTH_LONG).show();
            }
        });
    }
}